import { useEffect, useRef, useState } from 'react';
import mapboxgl from 'mapbox-gl';
import 'mapbox-gl/dist/mapbox-gl.css';
import { useProfiles } from '../contexts/ProfileContext';

mapboxgl.accessToken = import.meta.env.VITE_MAPBOX_ACCESS_TOKEN;

interface MapProps {
  selectedProfileId: number | null;
}

const Map: React.FC<MapProps> = ({ selectedProfileId }) => {
  const mapContainer = useRef<HTMLDivElement>(null);
  const map = useRef<mapboxgl.Map | null>(null);
  const { profiles } = useProfiles();
  const [lng, setLng] = useState(-98);
  const [lat, setLat] = useState(39);
  const [zoom, setZoom] = useState(3);

  useEffect(() => {
    if (map.current) return; // initialize map only once
    map.current = new mapboxgl.Map({
      container: mapContainer.current!,
      style: 'mapbox://styles/mapbox/streets-v11',
      center: [lng, lat],
      zoom: zoom
    });
  });

  useEffect(() => {
    if (!map.current) return;

    // Remove existing markers
    const markers = document.getElementsByClassName('mapboxgl-marker');
    while(markers[0]) {
      markers[0].remove();
    }

    // Add markers for all profiles
    profiles.forEach(profile => {
      const marker = new mapboxgl.Marker()
        .setLngLat([profile.longitude, profile.latitude])
        .addTo(map.current!);

      const popup = new mapboxgl.Popup({ offset: 25 }).setHTML(
        `<h3>${profile.name}</h3><p>${profile.address}</p>`
      );

      marker.setPopup(popup);
    });

    // If a profile is selected, zoom to it
    if (selectedProfileId) {
      const selectedProfile = profiles.find(p => p.id === selectedProfileId);
      if (selectedProfile) {
        map.current.flyTo({
          center: [selectedProfile.longitude, selectedProfile.latitude],
          zoom: 14
        });
      }
    }
  }, [profiles, selectedProfileId]);

  return <div ref={mapContainer} className="h-[500px]" />;
};

export default Map;

