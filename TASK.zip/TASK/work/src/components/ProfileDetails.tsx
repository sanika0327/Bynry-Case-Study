import { useParams } from "react-router-dom";
import { useProfiles } from "../contexts/ProfileContext";
import Map from "./Map";

const ProfileDetails = () => {
  const { id } = useParams<{ id: string }>();
  const { profiles, loading, error } = useProfiles();

  if (loading)
    return <div className="text-center mt-8">Loading profile...</div>;
  if (error)
    return <div className="text-center mt-8 text-red-500">Error: {error}</div>;

  const profile = profiles.find((p) => p.id === Number(id));

  if (!profile)
    return <div className="text-center mt-8">Profile not found</div>;

  return (
    <div className="container min-h-[150vh] text-siteWhite bg-siteGray">
      <div className=" mx-auto p-6 flex flex-col md:flex-row gap-6 items-center md:items-start">
        {/* Profile Picture and Basic Info */}
        <div className="md:w-1/3 flex flex-col items-center md:items-start text-center md:text-left">
          <img
            src={profile.photo}
            alt={profile.name}
            className="w-36 h-36 rounded-full shadow-lg mb-6 border-4 border-siteGreen"
          />
          <h1 className="text-3xl font-extrabold mb-2">{profile.name}</h1>
          <p className="text-sm text-siteGray-light mb-4 italic">
            {profile.description}
          </p>
        </div>

        {/* Additional Information */}
        <div className="md:w-2/3 bg-siteGray max-w-[600px] p-6 rounded-lg shadow-md shadow-siteGreen">
          <p className="mb-4">
            <span className="font-semibold text-siteGreen">Address : </span>{" "}
            {profile.address}
          </p>
          <p className="mb-4">
            <span className="font-semibold text-siteGreen">Contact:</span>{" "}
            {profile.contact}
          </p>
          <div className="mb-4">
            <span className="font-semibold text-siteGreen">Interests:</span>
            <ul className="list-disc list-inside ml-4 mt-2 space-y-2">
              {profile.interests.map((interest, index) => (
                <li key={index} className="text-sm text-siteWhite-light">
                  {interest}
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>
      <div className="w-full flex items-center justify-center mt-8">
        <div className="w-3/4 md:w-3/4 bg-siteGray-light p-4 rounded-lg shadow-md shadow-siteGreen border-2 border-siteGreen">
          <h2 className="text-center text-xl font-bold text-siteGreen mb-4">
            Location Map
          </h2>
          <div>
            <Map selectedProfileId={profile.id} />
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProfileDetails;
