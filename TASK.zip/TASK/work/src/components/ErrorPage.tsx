import { useNavigate } from 'react-router-dom';

const ErrorPage = () => {
  const navigate = useNavigate();

  const handleGoBack = () => {
    navigate(-1);
  };
  const handleGoHome = () => {
    navigate('/');
  };

  return (
    <div className="container min-h-screen flex flex-col justify-center items-center bg-siteGray text-siteWhite">
      <div className="text-center">
        <h1 className="text-4xl font-extrabold mb-4">Oops!</h1>
        <p className="text-lg mb-8">Something went wrong. We couldn't find the page you're looking for.</p>
        <p className="text-sm mb-8">Please check the URL.</p>
        <button
          onClick={handleGoBack}
          className="bg-siteGreen text-white px-6 py-2 rounded-lg hover:bg-siteGreen-dark transition"
        >
          Go Back
        </button>
        <button
          onClick={handleGoHome}
          className="bg-siteGreen text-white m-4 px-6 py-2 rounded-lg hover:bg-siteGreen-dark transition"
        >
          Go to Home
        </button>
      </div>
    </div>
  );
};

export default ErrorPage;
