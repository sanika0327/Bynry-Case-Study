import { useState } from 'react';
import { useProfiles, Profile } from '../contexts/ProfileContext';

const AdminPanel = () => {
  const { profiles, addProfile, updateProfile, deleteProfile } = useProfiles();
  const [editingProfile, setEditingProfile] = useState<Partial<Profile> | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (editingProfile) {
      // Geocode the address
      const response = await fetch(`https://api.mapbox.com/geocoding/v5/mapbox.places/${encodeURIComponent(editingProfile.address || '')}.json?access_token=${import.meta.env.VITE_MAPBOX_ACCESS_TOKEN}`);
      const data = await response.json();

      if (data.features && data.features.length > 0) {
        const [lng, lat] = data.features[0].center;
        const updatedProfile = {
          ...editingProfile,
          latitude: lat,
          longitude: lng,
        };

        if (editingProfile.id) {
          updateProfile(editingProfile.id, updatedProfile);
        } else {
          addProfile(updatedProfile as Omit<Profile, 'id'>);
        }
        setEditingProfile(null);
        setIsModalOpen(false);
      } else {
        alert('Could not geocode the address. Please try again.');
      }
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    if (name === 'interests') {
      setEditingProfile(prev => ({ ...prev, interests: value.split(',').map(i => i.trim()) }));
    } else {
      setEditingProfile(prev => ({ ...prev, [name]: value }));
    }
  };

  const openModal = (profile?: Profile) => {
    setEditingProfile(profile ? { ...profile } : null);
    setIsModalOpen(true);
  };

  const closeModal = () => {
    setIsModalOpen(false);
    setEditingProfile(null);
  };

  // Filter profiles based on search query
  const filteredProfiles = profiles.filter(profile => {
    return (
      profile.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      profile.description.toLowerCase().includes(searchQuery.toLowerCase())
    );
  });

  return (
    <div className="container mx-auto min-h-[100vh] text-siteWhite bg-siteGray p-4">
      <h1 className="text-2xl font-bold mb-4">Admin Panel</h1>
      
      {/* Search Bar */}
      <div className="mb-8">
        <input
          type="text"
          placeholder="Search profiles..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="block w-full sm:w-1/2 p-2 bg-siteWhite text-black border border-gray-600 rounded-lg mb-4"
        />
      </div>

      {/* Modal for Add/Edit Profile */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center">
          <div className="bg-siteGray p-6 rounded-lg shadow-lg w-[500px]">
            <h2 className="text-2xl font-bold mb-4">{editingProfile?.id ? 'Edit Profile' : 'Add Profile'}</h2>
            <form onSubmit={handleSubmit}>
              <input
                type="text"
                name="name"
                placeholder="Name"
                value={editingProfile?.name || ''}
                onChange={handleChange}
                className="block w-full p-2 mb-2 bg-siteWhite text-black border border-gray-600 rounded-lg"
              />
              <input
                type="text"
                name="photo"
                placeholder="Photo URL"
                value={editingProfile?.photo || ''}
                onChange={handleChange}
                className="block w-full p-2 mb-2 bg-siteWhite text-black border border-gray-600 rounded-lg"
              />
              <textarea
                name="description"
                placeholder="Description"
                value={editingProfile?.description || ''}
                onChange={handleChange}
                className="block w-full p-2 mb-2 bg-siteWhite text-black border border-gray-600 rounded-lg"
              />
              <input
                type="text"
                name="address"
                placeholder="Address"
                value={editingProfile?.address || ''}
                onChange={handleChange}
                className="block w-full p-2 mb-2 bg-siteWhite text-black border border-gray-600 rounded-lg"
              />
              <input
                type="text"
                name="contact"
                placeholder="Contact"
                value={editingProfile?.contact || ''}
                onChange={handleChange}
                className="block w-full p-2 mb-2 bg-siteWhite text-black border border-gray-600 rounded-lg"
              />
              <input
                type="text"
                name="interests"
                placeholder="Interests (comma-separated)"
                value={editingProfile?.interests?.join(', ') || ''}
                onChange={handleChange}
                className="block w-full p-2 mb-2 bg-siteWhite text-black border border-gray-600 rounded-lg"
              />
              <div className="flex justify-between mt-4">
                <button type="submit" className="bg-siteGreen text-white px-4 py-2 rounded">
                  {editingProfile?.id ? 'Update Profile' : 'Add Profile'}
                </button>
                <button type="button" onClick={closeModal} className="bg-red-500 text-white px-4 py-2 rounded">
                  Cancel
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
      
      <div className="mb-8">
        <button
          onClick={() => openModal()}
          className="bg-siteGreen text-white px-4 py-2 rounded mb-4"
        >
          Add New Profile
        </button>
      </div>

      {/* Temporary Edit/Delete Note */}
      <div className="text-sm text-center text-gray-500 mb-16">
        <p><strong>Note:</strong> Adds, edits and deletes are temporary as this is only a front-end React app with no backend integration.</p>
      </div>

      {/* Display Profiles in a 3-Column Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 justify-items-center gap-6">
        {filteredProfiles.map(profile => (
          <div key={profile.id} className="p-8 min-w-[300px] md:min-w-[400px] bg-siteGray-light rounded-lg shadow-md shadow-siteGreen border-2 border-siteGreen">
            <h2 className="text-xl text-center font-bold">{profile.name}</h2>
            <p className="text-sm text-center mb-4">{profile.description}</p>
            <div className="flex p-4 justify-evenly">
              <button
                onClick={() => openModal(profile)}
                className="bg-siteGreen text-white px-4 py-2 rounded mr-2"
              >
                Edit
              </button>
              <button
                onClick={() => deleteProfile(profile.id)}
                className="bg-[#5f2e2e] text-white px-4 py-2 rounded"
              >
                Delete
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default AdminPanel;
