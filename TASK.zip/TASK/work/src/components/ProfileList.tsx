import { useState } from 'react';
import { Link } from 'react-router-dom';
import { useProfiles } from '../contexts/ProfileContext';
import Map from './Map';
import './map.css';

const ProfileList = () => {
  const { profiles, loading, error } = useProfiles();
  const [selectedProfile, setSelectedProfile] = useState<number | null>(null);
  const [searchTerm, setSearchTerm] = useState('');

  const filteredProfiles = profiles.filter(profile =>
    profile.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    profile.address.toLowerCase().includes(searchTerm.toLowerCase())
  );

  if (loading) return <div className="text-center mt-8">Loading profiles...</div>;
  if (error) return <div className="text-center mt-8 text-red-500">Error: {error}</div>;

  return (
    <div className="container mx-auto p-4 flex flex-col md:flex-row bg-siteGray">
      <div className="md:w-1/2 pr-4">
        {/* Search Input */}
        <input
          type="text"
          placeholder="Search profiles..."
          className="w-full p-3 mb-6 bg-siteWhite text-black border border-gray-600 rounded-lg shadow-sm focus:ring focus:ring-black-500 focus:border-black-500 focus:outline-none"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
        />

        {/* Profile List */}
        <div className="space-y-6">
          {filteredProfiles.map(profile => (
            <div key={profile.id} className="p-6 bg-siteWhite rounded-lg shadow-lg flex items-center space-x-6 hover:shadow-xl transition-shadow duration-300">
              <img
                src={profile.photo}
                alt={profile.name}
                className="w-24 h-24 rounded-full object-cover border-[3px] border-siteGray"
              />
              <div className="flex-1">
                <h2 className="text-2xl font-semibold text-gray-800">{profile.name}</h2>
                <p className="text-gray-700 text-sm mb-3">{profile.description}</p>
                <div className="flex space-x-3 items-center">
                  <button
                    onClick={() => setSelectedProfile(profile.id)}
                    className="bg-siteGreen text-white px-4 py-2 rounded-lg shadow-md hover:bg-[#465e3d] focus:ring focus:ring-blue-300"
                  >
                    Show on Map
                  </button>
                  <Link
                    to={`/profile/${profile.id}`}
                    className="text-siteGreen hover:underline font-medium"
                  >
                    View Details
                  </Link>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Fixed Map on larger screens (md and above) */}
      <div className="mt-4 md:mt-0 md:fixed md:top-32 md:right-0 md:w-1/2 md:h-[calc(100vh-8rem)] md:p-4 md:bg-siteGray-light">
        <Map selectedProfileId={selectedProfile} />
      </div>
    </div>
  );
};

export default ProfileList;
