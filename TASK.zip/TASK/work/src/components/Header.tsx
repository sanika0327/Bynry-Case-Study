import { Link, NavLink } from 'react-router-dom';

const Header = () => {
  return (
    <header className="bg-[#545252] text-white p-4">
      <nav className="container mx-auto flex justify-between items-center">
        <Link to="/" className="text-2xl font-bold">Profile Explorer</Link>
        <ul className="flex gap-8 md:gap-16 md:px-16">
          <li>
            <NavLink
              to="/"
              className={({ isActive }) =>
                `text-lg ${isActive ? 'text-siteGreen font-bold' : 'text-white'}`
              }
            >
              Home
            </NavLink>
          </li>
          <li>
            <NavLink
              to="/admin"
              className={({ isActive }) =>
                `text-lg ${isActive ? 'text-siteGreen font-bold' : 'text-white'}`
              }
            >
              Admin
            </NavLink>
          </li>
        </ul>
      </nav>
    </header>
  );
};

export default Header;
