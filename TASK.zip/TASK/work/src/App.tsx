import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Header from './components/Header';
import ProfileList from './components/ProfileList';
import ProfileDetails from './components/ProfileDetails';
import AdminPanel from './components/AdminPanel';
import { ProfileProvider } from './contexts/ProfileContext';
import ErrorPage from './components/ErrorPage';

function App() {
  return (
    <Router>
      <ProfileProvider>
        <div className="App">
          <Header />
          <Routes>
            <Route path="/" element={<ProfileList />} />
            <Route path="/profile/:id" element={<ProfileDetails />} />
            <Route path="/admin" element={<AdminPanel />} />
            <Route path="*" element={<ErrorPage />} />
          </Routes>
        </div>
      </ProfileProvider>
    </Router>
  );
}

export default App;

