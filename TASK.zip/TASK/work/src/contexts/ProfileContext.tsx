import React, { createContext, useState, useContext } from 'react';

export interface Profile {
  id: number;
  name: string;
  photo: string;
  description: string;
  latitude: number;
  longitude: number;
  address: string;
  contact: string;
  interests: string[];
}

const mockProfiles: Profile[] = [
  {
    id: 1,
    name: "Soham Kulkarni",
    photo: "https://randomuser.me/api/portraits/men/1.jpg",
    description: "Software Developer",
    latitude: 40.7128,
    longitude: -74.0060,
    address: "New York, NY",
    contact: "john@example.com",
    interests: ["Coding", "Hiking", "Photography"]
  },
  {
    id: 2,
    name: "Sanika Kulkarni",
    photo: "https://randomuser.me/api/portraits/women/3.jpg",
    description: "Web Developer",
    latitude: 34.0522,
    longitude: -118.2437,
    address: "Los Angeles, CA",
    contact: "jane@example.com",
    interests: ["Design", "Travel", "Yoga"]
  },
  {
    id: 3,
    name: "Michael Brown",
    photo: "https://randomuser.me/api/portraits/men/2.jpg",
    description: "Project Manager",
    latitude: 41.8781,
    longitude: -87.6298,
    address: "Chicago, IL",
    contact: "michael@example.com",
    interests: ["Leadership", "Cooking", "Cycling"]
  },
  {
    id: 4,
    name: "Emily Davis",
    photo: "https://randomuser.me/api/portraits/women/2.jpg",
    description: "Data Scientist",
    latitude: 37.7749,
    longitude: -122.4194,
    address: "San Francisco, CA",
    contact: "emily@example.com",
    interests: ["Machine Learning", "Reading", "Gaming"]
  },
  {
    id: 5,
    name: "Chris Wilson",
    photo: "https://randomuser.me/api/portraits/men/3.jpg",
    description: "Marketing Specialist",
    latitude: 29.7604,
    longitude: -95.3698,
    address: "Houston, TX",
    contact: "chris@example.com",
    interests: ["Branding", "Music", "Traveling"]
  },
  {
    id: 6,
    name: "Sophia Martinez",
    photo: "https://randomuser.me/api/portraits/women/1.jpg",
    description: "Human Resources Manager",
    latitude: 39.7392,
    longitude: -104.9903,
    address: "Denver, CO",
    contact: "sophia@example.com",
    interests: ["People Management", "Yoga", "Cooking"]
  }
]
;

interface ProfileContextType {
  profiles: Profile[];
  loading: boolean;
  error: string | null;
  addProfile: (profile: Omit<Profile, 'id'>) => void;
  updateProfile: (id: number, profile: Partial<Profile>) => void;
  deleteProfile: (id: number) => void;
}

const ProfileContext = createContext<ProfileContextType | undefined>(undefined);

export const useProfiles = () => {
  const context = useContext(ProfileContext);
  if (!context) {
    throw new Error('useProfiles must be used within a ProfileProvider');
  }
  return context;
};

export const ProfileProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [profiles, setProfiles] = useState<Profile[]>(mockProfiles);
  const [loading] = useState(false);
  const [error] = useState<string | null>(null);

  const addProfile = (profile: Omit<Profile, 'id'>) => {
    const newProfile = { ...profile, id: Date.now() };
    setProfiles([...profiles, newProfile]);
  };

  const updateProfile = (id: number, updatedProfile: Partial<Profile>) => {
    setProfiles(profiles.map(p => p.id === id ? { ...p, ...updatedProfile } : p));
  };

  const deleteProfile = (id: number) => {
    setProfiles(profiles.filter(p => p.id !== id));
  };

  return (
    <ProfileContext.Provider value={{ profiles, loading, error, addProfile, updateProfile, deleteProfile }}>
      {children}
    </ProfileContext.Provider>
  );
};

