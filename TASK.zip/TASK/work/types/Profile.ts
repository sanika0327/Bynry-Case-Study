export interface Profile {
    id: number
    name: string
    photo: string
    description: string
    latitude: number
    longitude: number
    address: string
  }
  
  